import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_app/audioscreen.dart';
import 'package:flutter_app/homescreen.dart';
//import 'package:flutter_app/prayer.dart';
//import 'package:flutter_app/quranscreen.dart';
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selectindex= 0;
  List<Widget> _widgetList=[HomeScreen(),];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetList[selectindex],
  bottomNavigationBar: ConvexAppBar(
    backgroundColor: Color.fromARGB(255, 126, 73, 153),
    color: Color.fromARGB(255, 126, 73, 153),
    items: [
      TabItem(icon: Image.asset("assets/home.png"), title: 'Home'),
      // TabItem(icon: Image.asset("assets/quranicon.png"), title: 'QURAN'),
      // TabItem(icon: Image.asset("assets/audio.png"), title: 'AUDIO'),
      // TabItem(icon: Image.asset("assets/prayer.png"), title: 'PRAYER'),
      
    ],
    initialActiveIndex:0,
    onTap:updateIndex,
  )
);
  }
void updateIndex(index){
  setState(() {
      selectindex=index;
    });
}
}