import 'package:flutter/material.dart';
import 'dart:math';
import 'package:flutter_app/splashscreen.dart';
// import 'package:theme_provider/theme_provider.dart';
//import 'package:flutter_app/registerscreen.dart';
//import 'package:flutter_app/userlist.dart';

void main() {
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.purple)
            .copyWith(secondary: Colors.orange),
),
      
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    
    );
  }
}
