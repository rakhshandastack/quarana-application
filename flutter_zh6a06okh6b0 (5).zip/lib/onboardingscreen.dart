import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:flutter_app/mainscreen.dart';
//import 'homescreen.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 107, 141, 202),
          ),
          child: IntroductionScreen(
            pages: [
              PageViewModel(
                decoration: const PageDecoration(
                  pageColor: Color(0xffF8B44E),
                ),
                title: "READ QURAN",
                bodyWidget: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text(
                      "This is the book of guidance ",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
                image: Center(
                  child: Image.asset("assets/quranpak.jpg"),
                ),
              ),
              PageViewModel(
                decoration: const PageDecoration(
                  pageColor: Color(0xffF8B44E),
                ),
                title: "PRAYER ALERT",
                bodyWidget: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text(
                        "Do not make prayer a monologue...make it a conversation. "),
                  ],
                ),
                image: Center(child: Image.asset("assets/prayer.jpg")),
              ),
              PageViewModel(
                decoration: const PageDecoration(
                  pageColor: Color(0xffF8B44E),
                ),
                title: "ADHAN TIMINGS",
                bodyWidget: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text("Azan is the most beautiful sound in the world. "),
                  ],
                ),
                image: Center(child: Image.asset("assets/azan.jpg")),
              )
            ],
            onDone: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MainScreen()),
              );
            },
            showNextButton: true,
            next: const Icon(
              Icons.arrow_forward,
              color: Colors.black,
            ),
            done: const Text("DONE",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                )),
            dotsDecorator: DotsDecorator(
              size: const Size.square(10.0),
              activeSize: const Size(20.0, 10.0),
              color: Colors.pink,
              spacing: const EdgeInsets.symmetric(horizontal: 3.0),
              activeShape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
