import 'package:flutter/material.dart';
//import "package:dio/dio.dart";

import 'onboardingscreen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController email = TextEditingController();
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        title: Text(
          "𝙍𝙀𝙂𝙄𝙎𝙏𝙀𝙍 𝙎𝘾𝙍𝙀𝙀𝙉",
          style: TextStyle(
            color: Color.fromARGB(255, 3, 9, 48),
            fontSize: 40,
            fontWeight: FontWeight.w100,
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xffF8B44E),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xffF8B44E),
              Color.fromARGB(255, 56, 27, 94),
            ],
             begin: Alignment.bottomLeft,
             end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Form(
            key: _formKey,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
             TextFormField(
                controller: email,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  prefixIcon: Icon(Icons.email),
                  hintText: "enter email",),
                
                 validator:(value) {
                if (value!.isEmpty) {
                  return 'Please enter your email address';
                }
                if (!value.contains('@')) {
                  return 'Please enter a valid email address';
                }
                return null;
              },
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField( 
               validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter valid username';
                }
                return null;
              },
              
                controller: username,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  hintText: "enter username",
                  prefixIcon: Icon(Icons.person),
                ),
                 
              ),
              
              SizedBox(
                height: 10,
              ),
             TextFormField(
                controller: password,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  hintText: "enter password",
                  prefixIcon: Icon(
                    Icons.lock,
                  ),
                ),
                validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter your password';
                }
                if (value.length < 6) {
                  return 'Password must be at least 6 characters long';
                }
                return null;
              },
              ),
              
              SizedBox(
                height: 10,
              ),
              ElevatedButton(
                onPressed: () {
                   if (_formKey.currentState!.validate()) {
                    Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const OnBoardingScreen()),
                          );
                  
                }
                  //registeruser();
                },
                child: Text("REGISTER"),
              )
            ]),
          ),
        ),
      ),
    );
  }
}


