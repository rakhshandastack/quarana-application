import 'package:flutter/material.dart';
class PrayerScreen extends StatefulWidget {
  const PrayerScreen({super.key});

  @override
  State<PrayerScreen> createState() => _PrayerScreenState();
}

class _PrayerScreenState extends State<PrayerScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
       child: Scaffold(
        body: Center(
          child: Text("PRAYER"),
        ),
       ),
    );
  }
}